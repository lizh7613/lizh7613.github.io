/* This program will allow the user to input a number of processes, specifying their arrival time and
   processor time required before selecting a scheduling algorithm. The algorithm will be simulated,
   returning metrics on its performance to the user.
   Liz Hughes
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scheduler.h"

int main() {
  process* array = NULL;
  cpu* cpu1 = NULL;
  char scheduleChoice = 1;

  int numberOfInputs = inputNumberOfInputs();

  cpu1 = initialiseCpu();
  if(cpu1 == NULL) {
    printf("Memory allocation failed.\n");
    return ERROR;
  }

  array = allocateProcessArray(numberOfInputs);
  if(array == NULL) {
    printf("Memory allocation failed.\n");
    return ERROR;
  }

  initialiseValues(array, numberOfInputs);

  for(int i = 0; i < numberOfInputs; i++) {
    inputProcess(array, i);
  }

  printf("scheduleChoice: %d\n", scheduleChoice);
  while(strchr("SRTFsrtf", scheduleChoice) == NULL) {
    clearBuffer();

    printf("(S)TCF, (R)R, S(J)F or (F)IFO?\n");
    scanf(" %c", &scheduleChoice);
  
    if(scheduleChoice == 'S' || scheduleChoice == 's')
      simulateSTCF(array, cpu1, numberOfInputs);
    else if(scheduleChoice == 'R' || scheduleChoice == 'r')
      simulateRR(array, cpu1, numberOfInputs);
    else if(scheduleChoice == 'J' || scheduleChoice == 'j')
      simulateSJF(array, cpu1, numberOfInputs);
    else if(scheduleChoice == 'F' || scheduleChoice == 'f')
      simulateFIFO(array, cpu1, numberOfInputs);
    else
      printf("Invalid input \n");
  }

  postSimCalcs(array, cpu1, numberOfInputs);

  printResults(array, cpu1, numberOfInputs);

  return SUCCESS;
}

//this bubble sorts the array by burst time in ascending order
void sortBurstTime(process* array, int numberOfInputs) {
  process swapper;
  int swaps;

  while(1) {
    swaps = 0;

    for(int i = 0; i < (numberOfInputs - 1); i++) {
      if(array[i+1].burstTime < array[i].burstTime) {
        swapper = array[i+1];
        
        array[i+1] = array[i];
        
        array[i] = swapper;

        swaps++;
      }
    }
    if(swaps == 0) break;
  }
}

//this bubble sorts the array by arrival time in ascending order
void sortArrivalTime(process* array, int numberOfInputs) {
  process swapper;
  int swaps;

  while(1) {
    swaps = 0;

    for(int i = 0; i < (numberOfInputs - 1); i++) {
      if(array[i+1].arrivalTime < array[i].arrivalTime) {
        swapper = array[i+1];
        
        array[i+1] = array[i];
        
        array[i] = swapper;

        swaps++;
      }
    }
    if(swaps == 0) break;
  }
}

//this bubble sorts the array by completion time in ascending order
void sortCompletionTime(process* array, int numberOfInputs) {
  process swapper;
  int swaps;

  while(1) {
    swaps = 0;

    for(int i = 0; i < (numberOfInputs - 1); i++) {
      if(array[i+1].completionTime < array[i].completionTime) {
        swapper = array[i+1];
        
        array[i+1] = array[i];
        
        array[i] = swapper;

        swaps++;
      }
    }
    if(swaps == 0) break;
  }
}

//this clears the input buffer
void clearBuffer() {
  while(getchar() != '\n');
}

//this calculates certain derived metrics after the simulation has been run
void postSimCalcs(process* array, cpu* cpu1, int numberOfInputs) {
  for(int i = 0; i < numberOfInputs; i++) {
    array[i].turnaroundTime = array[i].completionTime - array[i].arrivalTime;
    array[i].responseTime = array[i].responseTime - array[i].arrivalTime; 
  }

  for(int i = 0; i < numberOfInputs; i++) {
    cpu1->averageResponse = cpu1->averageResponse + array[i].responseTime;
    cpu1->averageTurnaround = cpu1->averageTurnaround + array[i].turnaroundTime;
  }
  
  cpu1->averageResponse = cpu1->averageResponse / numberOfInputs;
  cpu1->averageTurnaround = cpu1->averageTurnaround / numberOfInputs;
  cpu1->usage = ((float)cpu1->cycles / (float)cpu1->clock) * 100;
}


//this initialises a cpu struct
cpu* initialiseCpu() {
  cpu* cpu1 = NULL;
  
  cpu1 = (cpu*)malloc(sizeof(cpu));
  
  cpu1->clock = 0;
  cpu1->cycles = 0;
  cpu1->usage = 0;
  cpu1->averageResponse = 0;
  cpu1->averageTurnaround = 0;

  return cpu1;
}

//prompt the user for the number of processes the array should hold
int inputNumberOfInputs() {
  int input;

  printf("Enter the number of processes you wish to simulate.\n");

  scanf("%d", &input);

  return input;
}

//allocate memory for an array of processes for a given size
process* allocateProcessArray(int numberOfInputs) {
  process* array = NULL;

  array = (process*)malloc(sizeof(process) * numberOfInputs);

  return array;       
}

//initialises values in the array
void initialiseValues(process* array, int numberOfInputs) {
  for(int i = 0; i < numberOfInputs; i++) {
    array[i].responseTime = -1;
  }
}

//prompt the user to fill the ID, arrival time and burst time for a single process
void inputProcess(process* array, int position) {
  clearBuffer();

  printf("Enter a new process ID.\n");
  scanf("%s", array[position].ID);

  clearBuffer();

  printf("Enter the arrival time for process ID %s.\n", array[position].ID);
  scanf("%d", &array[position].arrivalTime);
  if(array[position].arrivalTime < 0) {
    array[position].arrivalTime = 0;
    printf("Defaulting to 0.\n");
  }

  clearBuffer();

  printf("Enter the burst time for process ID %s.\n", array[position].ID);
  scanf("%d", &array[position].burstTime);
  if(array[position].burstTime < 1) {
    array[position].burstTime = 1;
    printf("Defaulting to 1.\n");
  }
}

//print the process IDs in order
void printResults(process* array, cpu* cpu1, int numberOfInputs) {
  for(int i = 0; i < numberOfInputs; i++) {
    printf("ID: %s\n", array[i].ID);
    printf("-------\n");
    printf("Response time: %d \n", array[i].responseTime);
    printf("Turnaround time: %d \n", array[i].turnaroundTime);
    printf("Completion time: %d,\n\n", array[i].completionTime);
  } 
  printf("\n");
  printf("The average turnaround time was %f.\n", cpu1->averageTurnaround);
  printf("The average response time was %f.\n", cpu1->averageResponse);
  printf("CPU utilization was at %f%%.\n", cpu1->usage);
}

//this simulates shortest time to completion first
void simulateSTCF(process* array, cpu* cpu1, int numberOfInputs) {
  while(totalBurst(array, numberOfInputs) > 0) {
    sortBurstTime(array, numberOfInputs);
    for(int i = 0; i < numberOfInputs; i++) {
      if(array[i].burstTime > 0 && array[i].arrivalTime <= cpu1->clock) {
        if(array[i].responseTime < 0)
          array[i].responseTime = cpu1->clock;
        array[i].burstTime--;
        if(array[i].burstTime == 0)
          array[i].completionTime = cpu1->clock + 1;
        cpu1->cycles++;
        cpu1->clock++; 
        break;
      }
      if(i == numberOfInputs - 1)
        cpu1->clock++;
    }
  }
}

//this simulates round robin
void simulateRR(process* array, cpu* cpu1, int numberOfInputs) {
  int timeQuantum;
  int check;

  printf("Enter the desired time quantum.\n");
  clearBuffer();
  scanf("%d", &timeQuantum);

  while(totalBurst(array, numberOfInputs) > 0) {
    check = 0;
    for(int i = 0; i < numberOfInputs; i++) {
      if(array[i].burstTime > 0 && array[i].arrivalTime <= cpu1->clock) {
        if(array[i].responseTime < 0)
          array[i].responseTime = cpu1->clock;
        check = 1;
        for(int j = 0; j < timeQuantum; j++) {
          array[i].burstTime--;
          cpu1->cycles++;
          cpu1->clock++;
          if(array[i].burstTime == 0) {
            array[i].completionTime = cpu1->clock;
            break;
          }
        }
      } 
    }
    if(check == 0)
      cpu1->clock++;
  }
  
  sortCompletionTime(array, numberOfInputs);
}

//this simulates shortest job first
void simulateSJF(process* array, cpu* cpu1, int numberOfInputs) {
  int check;

  sortBurstTime(array, numberOfInputs);

  while(totalBurst(array, numberOfInputs) > 0) {
    check = 0;
    for(int i = 0; i < numberOfInputs; i++) {
      if(array[i].burstTime > 0 && array[i].arrivalTime <= cpu1->clock) {
        check = 1;
        if(array[i].responseTime < 0)
          array[i].responseTime = cpu1->clock;
        while(array[i].burstTime > 0) {
          array[i].burstTime--;
          cpu1->clock++;
          cpu1->cycles++;
        }
        array[i].completionTime = cpu1->clock;
        break;
      }
    }
    if(check == 0)
      cpu1->clock++;
  }

  sortCompletionTime(array, numberOfInputs);
}

//this simulates FIFO
void simulateFIFO(process* array, cpu* cpu1, int numberOfInputs) {
  int check;

  sortArrivalTime(array, numberOfInputs);

  while(totalBurst(array, numberOfInputs) > 0) {
    check = 0;
    for(int i = 0; i < numberOfInputs; i++) {
      if(array[i].burstTime > 0 && array[i].arrivalTime <= cpu1->clock) {
        check = 1;
        if(array[i].responseTime < 0)
          array[i].responseTime = cpu1->clock;
        while(array[i].burstTime > 0) {
          array[i].burstTime--;
          cpu1->clock++;
          cpu1->cycles++;
        }
        array[i].completionTime = cpu1->clock;
        break;
      }
    }
    if(check == 0)
      cpu1->clock++;
  }
}

//adds up the total burst time remaining on all processes
int totalBurst(process* array, int numberOfInputs) {
  int total = 0;
  
  for(int i = 0; i < numberOfInputs; i++)
    total = total + array[i].burstTime;

  return total;
}