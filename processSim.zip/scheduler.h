#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ERROR -1;
#define SUCCESS 1;

typedef struct process {
  char ID[4];
  int arrivalTime;
  int burstTime;
  int responseTime;
  int waitTime;
  int completionTime;
  int turnaroundTime;
} process;

typedef struct cpu {
  int clock;
  int cycles;
  float usage;
  float averageResponse;
  float averageTurnaround;
} cpu;

int inputNumberOfInputs();
process* allocateProcessArray(int numberOfInputs);
cpu* initialiseCpu();
void initialiseValues(process* array, int numberOfInputs);
void inputProcess(process* array, int position);
void sortBurstTime(process* array, int numberOfInputs);
void sortArrivalTime(process* array, int numberOfInputs);
void printResults(process* array, cpu* cpu1, int numberOfInputs);
void simulateSTCF(process* array, cpu* cpu1, int numberOfInputs);
void simulateRR(process* array, cpu* cpu1, int numberOfInputs);
void simulateSJF(process* array, cpu* cpu1, int numberOfInputs);
void simulateFIFO(process* array, cpu* cpu1, int numberOfInputs);
void postSimCalcs(process* array, cpu* cpu1, int numberOfInputs);
void clearBuffer();
int totalBurst(process* array, int numberOfInputs);